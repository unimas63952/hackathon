package code.loginandregistration.com.helper;

/**
 * Created by Moin Khan on 2/21/2017.
 */
public class AppConfig {

    // local
    public static String BASE_URL = "http://172.16.20.137/login_register/api/";

    public static String login = BASE_URL + "login.php";
    public static String register = BASE_URL + "register.php";


}
